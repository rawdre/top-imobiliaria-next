import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

// Client is lazy — only fails at query time if env vars are missing, not at module load
export const supabase = supabaseUrl
  ? createClient(supabaseUrl, supabaseAnonKey)
  : createClient("https://placeholder.supabase.co", "placeholder");

export type Property = {
  id: string;
  title: string;
  type: "rent" | "sale";
  property_type: string;
  price: number;
  address: string;
  neighborhood: string;
  bedrooms: number;
  bathrooms: number;
  area: number;
  description: string;
  images: string[];
  featured: boolean;
  whatsapp?: string;
  created_at: string;
};
