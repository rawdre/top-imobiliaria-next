Pacote de handoff tecnico do projeto top-imobiliaria-next.

Inclui:
- codigo fonte (src)
- assets e admin estatico (public)
- configs do Next/TS/ESLint/PostCSS
- package.json e package-lock.json
- .env.local.example
- handoff tecnico completo

Exclui propositalmente:
- .env.local
- node_modules
- .next

Objetivo:
Permitir abertura e revisao em outra maquina com npm install + npm run dev.
